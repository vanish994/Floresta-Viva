# Floresta completa — PixelLab

Pacote de tiles de floresta em pixel art top-down. Os cinco tilesets Wang conectados têm tiles de 32×32 px e incluem metadados de colocação para autotiling. O atlas adicional de vegetação é um PNG transparente de 128×128 px, pensado como grade 4×4 de células de 32×32.

## Conteúdo

- `tilesets/01_lago_margem.png` — água parada do lago ↔ margem enlameada; `metadata/01_lago_margem.json` contém os cantos e as caixas de cada tile.
- `tilesets/02_margem_chao_floresta.png` — margem ↔ chão de folhas, raízes e musgo.
- `tilesets/03_chao_grama.png` — chão de floresta ↔ gramado com trevos, brotos e flores.
- `tilesets/04_grama_relevo.png` — gramado ↔ elevação baixa rochosa e coberta de musgo.
- `tilesets/05_grama_riacho.png` — gramado ↔ riacho raso de água corrente.
- `props/atlas_arvores_vegetacao.png` — árvores, arbusto, samambaia, capim, flores, tronco, toco, pedras e cogumelos em fundo transparente.
- `metadata/*.json` — dados de autotiling dos cinco tilesets Wang; use `bounding_box` para recortar cada tile da folha e os cantos NW/NE/SW/SE para escolher as peças.

## Ligações de terreno

A cadeia principal é lago → margem enlameada → chão de floresta → grama → relevo rochoso. O riacho é uma ramificação conectada à grama. Para encadear novos tilesets no PixelLab, os IDs-base gerados são:

- Lago: `d5e2a3fb-fee8-4b2f-be75-b7b84d63d431`
- Margem enlameada: `6b37f27d-2a52-4e42-8c44-04efe5220f76`
- Chão de floresta: `6fd7949f-ed8e-4071-8aca-0da04cb01d2e`
- Grama: `0447c42c-e0fa-4c1a-b5d3-1da1c9f64276`
- Relevo rochoso: `40ffdd94-0742-44ef-94f6-e9fd8d34e29e`
- Riacho: `abeaf1f1-ef0c-459b-b2c1-4b4fe1c2a9ac`

Os tilesets de terreno são Wang/corner-based. A folha de árvores e props é um atlas de imagem transparente; ela não é um tileset Wang autotilável.
